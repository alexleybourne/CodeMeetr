class Pricing < ApplicationRecord
    has_many :events
end
