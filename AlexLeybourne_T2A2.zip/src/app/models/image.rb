class Image < ApplicationRecord
  belongs_to :user
end
