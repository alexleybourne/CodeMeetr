class Promotion < ApplicationRecord
    has_many :events
end
