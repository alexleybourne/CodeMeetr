module PricingsHelper
end
